        <div class="col-md-2">
        <div class="sidebar content-box" style="display: block;">
                <ul class="nav">

                    <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-file"></i> File
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><?php echo $menure; ?></li>
                            <li><?php echo $menumu; ?></li>
                        </ul>
                    </li>


                    <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-th"></i> Wajib Pajak
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><?php echo $menunpwp; ?></li>
                            <li><?php echo $menuspt; ?></li>
                            <li><?php echo $menuskp; ?></li>
                        </ul>
                    </li>

                    <li><?php echo $menubendahara; ?></li>
                    <li><?php echo $menudash; ?></li>

                </ul>
        </div>
        </div>                   