<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');  
/* 
| ------------------------------------------------------------------- 
| EMAIL CONFIG 
| ------------------------------------------------------------------- 
| Konfigurasi email keluar melalui mail server
| */  
$config['protocol']='smtp';  
$config['smtp_host']='mail.pemeringkatan2015.com';  
$config['smtp_port']='26';  
$config['smtp_user']='pemeringkatan@pemeringkatan2015.com';  
$config['smtp_pass']='081556416082';  
$config['charset']='utf-8';  
$config['newline']="\r\n";  

?>